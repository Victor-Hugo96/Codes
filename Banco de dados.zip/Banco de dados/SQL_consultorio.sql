create database consultorio
go 

use consultorio

create table medicos
(
Francisco char(15),
Jose char(20),
data_nasc date null,
endereco char(40) not null,
cidade char(15) not null,

);

use consultorio

create table pacientes
(
Marcio char(15),
Farias char(20),
data_nasc date null,
endereco char(40) not null,
cidade char(15) not null,

);


