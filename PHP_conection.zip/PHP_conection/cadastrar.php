<?php
define('DB_HOST'        , "LAPTOP-32HOCQQG\SQLEXPRESS");
define('DB_USER'        , "sa");
define('DB_PASSWORD'    , "sa");
define('DB_NAME'        , "login");
define('DB_DRIVER'      , "sqlsrv");

session_start();
include('conexao.php');

if(!empty($_POST['usuario']) || !empty($_POST['senha'])){
    header('Location: registrar.php');
}

try{
    $Conexao  = Conexao::getConnection();

    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];
    $query = $Conexao -> query("insert into Usuario(Usuario, Senha) values( '{$usuario}' , '{$senha}')");
    header('Location: index.php');
   


}
catch(Exception $e){
    echo $e -> getMessage();
    

}

?>