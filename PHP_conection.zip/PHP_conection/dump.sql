use login

 
CREATE TABLE cadastro (
  usuario_id INT  identity,
  usuario VARCHAR(200) NOT NULL,
  senha VARCHAR(32) NOT NULL,
  nome VARCHAR(100) NOT NULL,
  data_cadastro DATETIME NOT NULL,
  PRIMARY KEY (usuario_id));
  SET IDENTITY_INSERT dbo.cadastro ON;
INSERT INTO cadastro(usuario_id,usuario,senha, nome, data_cadastro) VALUES (1,'Ana','1234', 'Aninha', '2019-01-11 19:42:12');