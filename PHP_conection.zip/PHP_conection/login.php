<?php
define('DB_HOST'        , "LAPTOP-32HOCQQG\SQLEXPRESS");
define('DB_USER'        , "sa");
define('DB_PASSWORD'    , "sa");
define('DB_NAME'        , "login");
define('DB_DRIVER'      , "sqlsrv");

session_start();
include('conexao.php');

if(empty($_POST['usuario']) || empty($_POST['senha'])) {
	header('Location: index.php');
	exit();
}

try{

	
    $Conexao    = Conexao::getConnection();
    
	$usuario = $_POST['usuario'];
	$senha = $_POST['senha'];
	$query = $Conexao->query("select usuario from usuario where usuario = '{$usuario}' and senha = '{$senha}'");
	$row = $query ->fetchAll();
	echo $usuario;
		foreach ($row as $rows){
			$user = $rows ["usuario"];
			echo $user;
		}

	if($user <> null) {
		$_SESSION['usuario'] = $usuario;
		header('Location: painel.php');
		exit();
	} else {
		$_SESSION['nao_autenticado'] = true;
		header('Location: index.php');
		exit();
	}
}catch(Exception $e){

    echo $e->getMessage();
    exit;

 }

 ?>